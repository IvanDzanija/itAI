import argparse
import heapq
from collections import deque


parser = argparse.ArgumentParser()
parser.add_argument("--alg", choices=["bfs", "ucs", "astar"], help="algorithm")
parser.add_argument("--ss", required=True, help="Graph desc")
parser.add_argument("--h", help="Heuristic desc")
parser.add_argument(
    "--check-optimistic",
    action="store_true",
)
parser.add_argument(
    "--check-consistent",
    action="store_true",
)
args = parser.parse_args()

# Parse the graph description
start = None
end = set()
graph = {}
with open(args.ss) as f:
    index = 0
    for line in f:
        if line[0] == "#":
            continue
        index += 1
        if index == 1:
            start = line.strip()
        elif index == 2:
            for state in line.split():
                end.add(state)
        else:
            currentSplit = line.split(":")
            currentState = currentSplit[0].strip()
            graph[currentState] = set()
            for neighbor in currentSplit[1].split():
                neighbor, weight = neighbor.split(",")
                graph[currentState].add((neighbor, float(weight)))

heuristic = {}
if args.h:
    with open(args.h) as f:
        for line in f:
            currentSplit = line.split(":")
            heuristic[currentSplit[0].strip()] = float(currentSplit[1].strip())


def printSucc(node, pathing, cost):
    print("[FOUND_SOLUTION]: yes")
    print("[STATES_VISITED]:", len(pathing))
    path = deque()
    while node != "nullNode":
        path.appendleft(node)
        node = pathing[node]
    print("[PATH_LENGTH]:", len(path))
    print("[TOTAL_COST]:", cost)
    print("[PATH]:", end=" ")
    while path:
        node = path.popleft()
        if path:
            print(node, end=" => ")
        else:
            print(node)
    return


def printFail():
    print("[FOUND_SOLUTION]: no")
    return


def bfs():
    q = deque()
    previous = {}
    q.append((start, "nullNode", 0))
    while q:
        node, prev, cost = q.popleft()
        if node in previous.keys():  # NEED THIS CHECK
            continue
        previous[node] = prev
        if node in end:
            return printSucc(node, previous, cost)
        for neighbor, weight in sorted(graph[node]):
            if neighbor not in previous.keys():
                q.append((neighbor, node, cost + weight))
    return printFail()


def ucs():
    pq = []
    heapq.heappush(pq, (0, start, "nullNode"))
    previous = {}
    while pq:
        cost, node, prev = heapq.heappop(pq)
        if node in previous.keys():
            continue
        previous[node] = prev
        if node in end:
            return printSucc(node, previous, cost)
        for neighbor, weight in graph[node]:
            if neighbor not in previous.keys():
                heapq.heappush(pq, (cost + weight, neighbor, node))
    return printFail()


def astar():
    pq = []
    heapq.heappush(pq, (0 + heuristic[start], start, "nullNode"))
    previous = {}
    while pq:
        cost, node, prev = heapq.heappop(pq)
        cost -= heuristic[node]
        if node in previous.keys():
            continue
        previous[node] = prev
        if node in end:
            return printSucc(node, previous, cost)
        for neighbor, weight in graph[node]:
            if neighbor not in previous.keys():
                heapq.heappush(
                    pq, (cost + weight + heuristic[neighbor], neighbor, node)
                )
    return printFail()


def printOptimistic(checked):
    print("# HEURISTIC-OPTIMISTIC", args.h)
    optimistic = True
    for node in sorted(graph.keys()):
        print("[CONDITION]", end=": ")
        if node in checked.keys() and checked[node] >= heuristic[node]:
            print("[OK] h(" + node + ") <= h*:", heuristic[node], "<=", checked[node])
        else:
            print("[ERR] h(" + node + ") <= h*:", heuristic[node], "<=", checked[node])
            optimistic = False
    print(
        "[CONCLUSION]:",
        ("Heuristic is optimistic." if optimistic else "Heuristic is not optimistic."),
    )
    return


def checkOptimistic():
    checked = {}
    for node in graph.keys():
        if node in checked.keys():
            continue
        pq = []
        heapq.heappush(pq, (0, node, "nullNode"))
        previous = {}
        while pq:
            cost, node, prev = heapq.heappop(pq)
            if node in previous.keys():
                continue
            previous[node] = (prev, cost)
            if node in end:
                while node != "nullNode":
                    checked[node] = cost - previous[node][1]
                    node = previous[node][0]
                break
            for neighbor, weight in graph[node]:
                if neighbor not in previous.keys():
                    heapq.heappush(pq, (cost + weight, neighbor, node))
    printOptimistic(checked)
    return


def checkConsistent():
    print("# HEURISTIC-CONSISTENT", args.h)
    consistent = True
    for node in graph.keys():
        for neighbor, weight in graph[node]:
            print("[CONDITION]", end=": ")
            if heuristic[node] <= heuristic[neighbor] + weight:
                print(
                    "[OK] h(" + node + ") <= h(" + neighbor + ") + c:",
                    heuristic[node],
                    "<=",
                    heuristic[neighbor],
                    "+",
                    weight,
                )
            else:
                print(
                    "[ERR] h(" + node + ") <= h(" + neighbor + ") + c:",
                    heuristic[node],
                    "<=",
                    heuristic[neighbor],
                    "+",
                    weight,
                )
                consistent = False

    print(
        "[CONCLUSION]:",
        ("Heuristic is consistent." if consistent else "Heuristic is not consistent."),
    )
    return


if args.alg == "bfs":
    bfs()
elif args.alg == "ucs":
    ucs()
elif args.alg == "astar":
    astar()
if args.check_optimistic:
    checkOptimistic()
if args.check_consistent:
    checkConsistent()
